import java.io.FileNotFoundException;

public class Client {

    public static void main(String[] args) throws FileNotFoundException
    {
        OS os = new OS();
        os.launch();
    }
}